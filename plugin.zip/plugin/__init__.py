def classFactory(iface):
    from .GeoZONE import GeoZONE
    return GeoZONE(iface)